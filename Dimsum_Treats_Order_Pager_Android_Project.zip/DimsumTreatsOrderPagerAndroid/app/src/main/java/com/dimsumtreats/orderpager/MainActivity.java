package com.dimsumtreats.orderpager;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;
import org.json.JSONArray;
import android.speech.tts.Voice;

public class MainActivity extends Activity {
    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private final AtomicInteger utteranceId = new AtomicInteger(0);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new TtsBridge(), "AndroidTTS");
        setContentView(webView);

        tts = new TextToSpeech(this, status -> {
            ttsReady = status == TextToSpeech.SUCCESS;
            if (ttsReady) {
                tts.setLanguage(Locale.US);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) {}
                    @Override public void onDone(String id) { runOnUiThread(() -> webView.evaluateJavascript("window.__nativeTtsDone && window.__nativeTtsDone()", null)); }
                    @Override public void onError(String id) { runOnUiThread(() -> webView.evaluateJavascript("window.__nativeTtsDone && window.__nativeTtsDone()", null)); }
                });
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class TtsBridge {
        @JavascriptInterface public boolean available() { return ttsReady; }

        @JavascriptInterface public String voices() {
            JSONArray arr = new JSONArray();
            if (!ttsReady || tts.getVoices() == null) return arr.toString();
            for (Voice v : tts.getVoices()) {
                try { if (v.getLocale().getLanguage().equals("en")) arr.put(v.getName()); } catch (Exception ignored) {}
            }
            return arr.toString();
        }

        @JavascriptInterface public void speak(String text, float rate, float pitch, String voiceName, float volume) {
            if (!ttsReady) return;
            try {
                tts.setSpeechRate(Math.max(0.1f, Math.min(3f, rate)));
                tts.setPitch(Math.max(0.5f, Math.min(2f, pitch)));
                if (voiceName != null && !voiceName.isEmpty() && tts.getVoices() != null) {
                    for (Voice v : tts.getVoices()) if (voiceName.equals(v.getName())) { tts.setVoice(v); break; }
                }
                String id = "dt_" + utteranceId.incrementAndGet();
                Bundle params = new Bundle();
                params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, Math.max(0f, Math.min(1f, volume)));
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, id);
            } catch (Exception ignored) {}
        }

        @JavascriptInterface public void stop() { if (ttsReady) tts.stop(); }
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
