DIMSUM TREATS ORDER PAGER — ANDROID APK PROJECT
Version 6.0

This is a ready Android Studio project based on the V6 Final web app.
It includes a native Android Text-to-Speech bridge so voice calling can work more reliably inside the APK than browser-only speechSynthesis.

IMPORTANT:
The current build environment does not have the Android SDK/Gradle build tools installed, so an already-compiled .apk cannot be produced here in this session.

To build the APK on a computer:
1. Install Android Studio.
2. Open this folder as an existing project.
3. Let Gradle sync/download the Android build tools.
4. Choose Build > Build App Bundle(s) / APK(s) > Build APK(s).
5. The APK will be in app/build/outputs/apk/debug/.

The app is designed for Android and works offline after installation.
