DIMSUM TREATS ORDER PAGER V7 — LIVE PHONE → PC TEST

What changed:
- V6 Android app kept as base.
- Phone starts a local Wi-Fi display server on port 8765.
- Phone shows a PC Display URL and 4-digit Pairing Code.
- PC opens the URL in Chrome/Edge and enters the pairing code.
- Phone order status is synchronized to the PC display over the same Wi-Fi.
- Multiple NOW SERVING orders are supported.
- PREPARING and DONE are supported in the cashier screen.

TEST:
1. Install the new V7 APK on the cashier phone.
2. Connect phone and PC to the same Wi-Fi.
3. Open the app and wait for LIVE CUSTOMER DISPLAY to show the PC URL/code.
4. On PC, open the displayed URL.
5. Enter the 4-digit pairing code.
6. On phone enter DT36 and press CALL ORDER.
7. PC should show DT36 under NOW SERVING.
8. Enter DT37 and press CALL ORDER. Both DT36 and DT37 should remain visible.
9. Press DONE for DT36. It should disappear from the PC.

NOTE:
This V7 project is the development build. Build it with Android Gradle Plugin/Gradle or the existing GitHub Actions workflow.
