package com.dimsumtreats.orderpager;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;
import org.json.JSONArray;
import android.speech.tts.Voice;
import java.io.*;
import java.net.*;
import java.net.NetworkInterface;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private final AtomicInteger utteranceId = new AtomicInteger(0);
    private LiveServer liveServer;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new TtsBridge(), "AndroidTTS");
        setContentView(webView);

        tts = new TextToSpeech(this, status -> {
            ttsReady = status == TextToSpeech.SUCCESS;
            if (ttsReady) {
                tts.setLanguage(Locale.US);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) {}
                    @Override public void onDone(String id) { runOnUiThread(() -> webView.evaluateJavascript("window.__nativeTtsDone && window.__nativeTtsDone()", null)); }
                    @Override public void onError(String id) { runOnUiThread(() -> webView.evaluateJavascript("window.__nativeTtsDone && window.__nativeTtsDone()", null)); }
                });
            }
        });
        liveServer = new LiveServer();
        liveServer.start();
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class TtsBridge {
        @JavascriptInterface public boolean available() { return ttsReady; }

        @JavascriptInterface public String voices() {
            JSONArray arr = new JSONArray();
            if (!ttsReady || tts.getVoices() == null) return arr.toString();
            for (Voice v : tts.getVoices()) {
                try { if (v.getLocale().getLanguage().equals("en")) arr.put(v.getName()); } catch (Exception ignored) {}
            }
            return arr.toString();
        }

        @JavascriptInterface public void speak(String text, float rate, float pitch, String voiceName, float volume) {
            if (!ttsReady) return;
            try {
                tts.setSpeechRate(Math.max(0.1f, Math.min(3f, rate)));
                tts.setPitch(Math.max(0.5f, Math.min(2f, pitch)));
                if (voiceName != null && !voiceName.isEmpty() && tts.getVoices() != null) {
                    for (Voice v : tts.getVoices()) if (voiceName.equals(v.getName())) { tts.setVoice(v); break; }
                }
                String id = "dt_" + utteranceId.incrementAndGet();
                Bundle params = new Bundle();
                params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, Math.max(0f, Math.min(1f, volume)));
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, id);
            } catch (Exception ignored) {}
        }

        @JavascriptInterface public void stop() { if (ttsReady) tts.stop(); }

        @JavascriptInterface public String liveInfo() {
            return liveServer == null ? "{}" : liveServer.infoJson();
        }

        @JavascriptInterface public void publishState(String json) {
            if (liveServer != null) liveServer.setState(json);
        }
    }


    private class LiveServer {
        private ServerSocket serverSocket;
        private Thread thread;
        private volatile boolean running;
        private volatile String state = "{\"preparing\":[],\"nowServing\":[]}";
        private final String code = String.format("%04d", new Random().nextInt(10000));
        private int port = 8765;

        void start() {
            thread = new Thread(() -> {
                try {
                    serverSocket = new ServerSocket(port);
                    serverSocket.setReuseAddress(true);
                    running = true;
                    while (running) {
                        try { Socket socket = serverSocket.accept(); new Thread(() -> handle(socket)).start(); }
                        catch (IOException ignored) {}
                    }
                } catch (IOException e) { running = false; }
            }, "DT-Live-Server");
            thread.start();
        }

        void stop() {
            running = false;
            try { if (serverSocket != null) serverSocket.close(); } catch (Exception ignored) {}
        }

        void setState(String json) { if (json != null && json.length() < 200000) state = json; }

        String infoJson() {
            JSONObject o = new JSONObject();
            try { o.put("code", code); o.put("ip", localIp()); o.put("port", port); o.put("url", "http://" + localIp() + ":" + port + "/display"); o.put("running", running); } catch (Exception ignored) {}
            return o.toString();
        }

        private String localIp() {
            try {
                for (java.util.Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();) {
                    NetworkInterface ni = en.nextElement();
                    if (!ni.isUp() || ni.isLoopback()) continue;
                    for (java.util.Enumeration<InetAddress> a = ni.getInetAddresses(); a.hasMoreElements();) {
                        InetAddress addr = a.nextElement();
                        String ip = addr.getHostAddress();
                        if (ip != null && ip.indexOf(':') < 0 && !ip.startsWith("127.")) return ip;
                    }
                }
            } catch (Exception ignored) {}
            return "PHONE-IP";
        }

        private void handle(Socket socket) {
            try (Socket s = socket) {
                s.setSoTimeout(4000);
                BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
                String request = r.readLine();
                if (request == null) return;
                String[] parts = request.split(" ");
                String path = parts.length > 1 ? parts[1] : "/";
                while (true) { String line = r.readLine(); if (line == null || line.isEmpty()) break; }
                if (path.startsWith("/api/info")) respond(s, "application/json", infoJson());
                else if (path.startsWith("/api/state")) {
                    String q = query(path, "code");
                    if (!code.equals(q)) { respondStatus(s, 403, "text/plain", "Invalid pairing code"); }
                    else respond(s, "application/json", state);
                } else if (path.startsWith("/display")) {
                    String html = readAsset("display.html");
                    respond(s, "text/html; charset=utf-8", html);
                } else if (path.startsWith("/assets/")) {
                    String asset = path.substring(1);
                    byte[] data = readAssetBytes(asset);
                    if (data == null) respondStatus(s, 404, "text/plain", "Not found");
                    else respondBytes(s, contentType(asset), data);
                } else respond(s, "text/plain", "Dimsum Treats Live Display");
            } catch (Exception ignored) {}
        }

        private String query(String path, String key) {
            int q = path.indexOf('?'); if (q < 0) return "";
            String[] params = path.substring(q+1).split("&");
            for (String p : params) { String[] kv=p.split("=",2); if(kv.length==2 && key.equals(kv[0])) return kv[1]; }
            return "";
        }
        private String readAsset(String name) throws IOException { return new String(readAssetBytes(name), StandardCharsets.UTF_8); }
        private byte[] readAssetBytes(String name) throws IOException {
            try (InputStream in = getAssets().open(name); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] b=new byte[8192]; int n; while((n=in.read(b))!=-1) out.write(b,0,n); return out.toByteArray();
            } catch (Exception e) { return null; }
        }
        private String contentType(String name) { if(name.endsWith(".png")) return "image/png"; if(name.endsWith(".jpg")||name.endsWith(".jpeg")) return "image/jpeg"; if(name.endsWith(".css")) return "text/css"; return "text/plain"; }
        private void respond(Socket s, String type, String body) throws IOException { respondBytes(s,type,body.getBytes(StandardCharsets.UTF_8)); }
        private void respondBytes(Socket s, String type, byte[] body) throws IOException {
            OutputStream out=s.getOutputStream(); String h="HTTP/1.1 200 OK\r\nContent-Type: "+type+"\r\nContent-Length: "+body.length+"\r\nCache-Control: no-store\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n"; out.write(h.getBytes(StandardCharsets.UTF_8)); out.write(body); out.flush();
        }
        private void respondStatus(Socket s,int status,String type,String body)throws IOException{byte[] b=body.getBytes(StandardCharsets.UTF_8);OutputStream out=s.getOutputStream();String h="HTTP/1.1 "+status+"\r\nContent-Type: "+type+"\r\nContent-Length: "+b.length+"\r\nConnection: close\r\n\r\n";out.write(h.getBytes(StandardCharsets.UTF_8));out.write(b);out.flush();}
    }

    @Override protected void onDestroy() {
        if (liveServer != null) liveServer.stop();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
