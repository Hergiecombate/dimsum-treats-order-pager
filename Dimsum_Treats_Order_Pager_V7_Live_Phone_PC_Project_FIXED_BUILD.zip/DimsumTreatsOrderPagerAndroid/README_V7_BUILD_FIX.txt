V7 BUILD FIX

Fixed MainActivity.java network enumeration compilation issue by using fully-qualified java.util.Enumeration.
This ZIP is intended to replace the previous V7 Live Phone/PC project ZIP in the GitHub repository.

Expected GitHub Actions filename:
Dimsum_Treats_Order_Pager_V7_Live_Phone_PC_Project.zip
